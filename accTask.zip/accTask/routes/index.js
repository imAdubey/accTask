var express = require('express');
var userModel = require('../models/user');

var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next){
  userModel.find({}).exec().then((data)=>{
    res.render('index', { title: 'ACC Task', msg: '', errmsg: '', userList: data });
  }).catch((err)=>{
    res.json(err);
  });
});

router.post('/addDetails', (req, res, next)=>{
  var fName = req.body.fname;
  var lName = req.body.lname;
  var email = req.body.email;
  
  new userModel({
    fname: fName,
    lname: lName,
    email: email
  }).save().then((data)=>{
    res.redirect('/');
  }).catch((err)=>{
    res.json(err);
  });

});

module.exports = router;
