var mongoose = require('mongoose');

mongoose.connect('mongodb+srv://abd:abd123@cluster0.xm3u7.mongodb.net/accTask?retryWrites=true&w=majority', {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true});

var connDB = mongoose.connection;

if(connDB){
    console.log("Connection Established!");
}

var userSchema = new mongoose.Schema({
    fname: {type: String},
    lname: {type: String},
    email: {type: String},
    date: {type: Date, default: Date.now}
});

var userModel = mongoose.model('users', userSchema);

module.exports = userModel;